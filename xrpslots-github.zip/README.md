# XRPSlots – Arcade XRPL Deluxe

This is a static front-end demo for **XRPSlots**, a XRP-themed slot machine with arcade sounds and an XRPL payment hook.

It includes:
- A single-page `index.html` slot machine UI
- Animated spinner GIF
- Multiple sound effects (spin, win, lose, near-miss, jackpot fanfare, ambient casino, etc.)
- A frontend hook that POSTs spin results to `/api/xrpl-spin` with:
  - `result`: `"WIN"` or `"LOSE"`
  - `wallet`: XRPL address entered into the input field

> ⚠️ **No real gambling logic, custody, or XRPL signing happens in this front-end.**
> It is **demo-only** until you implement and secure the backend.

---

## 🧩 Files

- `index.html` – main app
- `spin.gif` – small reel spinner indicator
- `spin_arcade.wav` – reel spin sound
- `win_arcade.wav` – win sound
- `lose_arcade.wav` – lose sound
- `button_click.wav` – button press click
- `coin_spray.wav` – bonus coin spray on win
- `near_miss.wav` – tension sound on near-miss
- `ambient_casino.wav` – low-volume casino ambience loop
- `reel_stop.wav` – tick when reels stop
- `jackpot_fanfare.wav` – extra fanfare on triple 7s
- `low_balance.wav` – warning sound when demo balance is low
- `error_beep.wav` – error sound (no balance / XRPL hook failure)

All of these are referenced directly from `index.html` in the same folder.

---

## 🚀 Run Locally

1. Download this folder (or the zip) to your computer.
2. Open `index.html` in a browser (double-click or drag into the window).
3. Make sure all `.wav` files and `spin.gif` live in the **same folder** as `index.html`.

> If sounds do not play automatically, your browser might require a first **click** to allow audio (autoplay restrictions).

---

## 🌐 Deploy to GitHub Pages (Free Hosting)

1. Create a new public repository on GitHub, e.g. `XRPSlots`.
2. Upload **all files** from this folder into the repo root:
   - `index.html`
   - all `.wav` and `.gif` files
3. Commit & push (or use the web upload interface).
4. In the repo on GitHub, go to:
   - **Settings → Pages**
   - Source: **Deploy from a branch**
   - Branch: `main`
   - Folder: `/ (root)`
5. Save.

GitHub will give you a live URL such as:

`https://YOUR-USERNAME.github.io/XRPSlots/`

That’s your live XRPSlots front-end.

---

## 🔗 XRPL Payment Hook

The front-end will `POST` to:

`/api/xrpl-spin`

with JSON:

```json
{
  "result": "WIN" | "LOSE",
  "wallet": "rXXXXXXXXXXXXXXXXXXXXXXXX"
}
```

The backend (not included) should:

- Verify/handle incoming bets from the user.
- On `WIN`, authorize a payment from your house wallet to `wallet`.
- On `LOSE`, either do nothing or log analytics.
- Validate and secure all requests.

You can host the backend separately (Render, Railway, Vercel functions, etc.) and change the fetch URL in `index.html` to point to your live backend:

```js
fetch('https://your-backend-domain.com/api/xrpl-spin', { ... });
```

---

## ⚠️ Disclaimer

- This is a **demo UI** only, not production-ready gambling software.
- Add proper:
  - Security
  - Rate-limiting
  - Jurisdictional/legal compliance
  - Wallet/bankroll management

before using it in any real-money or real-asset context.